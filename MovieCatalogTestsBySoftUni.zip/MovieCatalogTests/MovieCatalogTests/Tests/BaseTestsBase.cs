﻿using MovieCatalogTests.Pages;
using OpenQA.Selenium.Chrome;

public class BaseTests
{
    public IWebDriver driver;

    public LoginPage loginPage;

    public AddMoviesPage addMoviesPage;

    public AllMovisePages allMovisePages;

    public EditMoviePage editMoviePage;

    public WatchedMoviePage watchedMoviePage;

    [OneTimeSetUp]
    public void OneTImeSetup()
    {
        var chromeOptions = new ChromeOptions();
        chromeOptions.AddUserProfilePreference("profile.password_manager_enabled", false);
        chromeOptions.AddArgument("--disable-search-engine-choice-screen");

        driver = new ChromeDriver(chromeOptions);
        driver.Manage().Window.Maximize();
        driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

        loginPage = new LoginPage(driver);
        addMoviesPage = new AddMoviesPage(driver);  
        allMovisePages = new AllMovisePages(driver);
        editMoviePage = new EditMoviePage(driver);
        watchedMoviePage = new WatchedMoviePage(driver);
        

        loginPage.OpenPage();
       

        loginPage.PerformLogin("asd@gmail.com", "123456");
        

    }

    [OneTimeTearDown]
    public void OneTImeTearDown()
    {
        driver.Quit();
        driver.Dispose();
    }

    public string GenerateRandomTitle()
    {
        var random = new Random();
        return "TITLE: " + random.Next(10000, 100000);
    }

    public string GenerateRandomDescription()
    {
        var random = new Random();
        return "DESCRIPTION: " + random.Next(10000, 100000);
    }
}