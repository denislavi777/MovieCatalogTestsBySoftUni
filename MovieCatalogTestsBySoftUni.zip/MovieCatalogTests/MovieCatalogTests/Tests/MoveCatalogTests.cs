﻿

using MovieCatalogTests.Pages;

namespace MovieCatalogTests.Tests
{
    public class MoveCatalogTests : BaseTests
    {
        public string lastMovieTitle;
        public string lastMovieDescription;

        [Test, Order (1)]
        public void AddMovieWithoutTitle()
        {
            addMoviesPage.OpenPage();

            addMoviesPage.TitleInput.Clear();

            addMoviesPage.AddButton.Click();

            addMoviesPage.AssertEmptyTitleMessage();

        }

        [Test, Order(2)]
        public void AddMovieWithoutDescription()
        {
            lastMovieTitle = GenerateRandomTitle();

            addMoviesPage.OpenPage();

            addMoviesPage.TitleInput.SendKeys(lastMovieTitle);

            addMoviesPage.AddButton.Click();

            addMoviesPage.AssertEmptyDescriptionMessage();

        }

        [Test, Order(3)]
        public void AddMovieWithTitleAndDescription()
        {
            lastMovieTitle = GenerateRandomTitle();

            lastMovieDescription = GenerateRandomDescription();

            addMoviesPage.OpenPage();

            addMoviesPage.TitleInput.SendKeys(lastMovieTitle);

            addMoviesPage.DescriptionInput.SendKeys(lastMovieDescription);

            addMoviesPage.AddButton.Click();

            allMovisePages.NavigateToLastPage();

            Assert.That(allMovisePages.LastMovieTitle.Text.Trim, Is.EqualTo(lastMovieTitle), "The Title is not Expected");

        }

        [Test, Order(4)]
        public void EditMovieTest()
        {
            lastMovieTitle = GenerateRandomTitle() + "EDITED";

            lastMovieDescription = GenerateRandomDescription();

            allMovisePages.OpenPage();
            allMovisePages.NavigateToLastPage();
            allMovisePages.LastMovieEditButton.Click();
            editMoviePage.TitleInput.Clear();
            editMoviePage.TitleInput.SendKeys(lastMovieTitle);
            editMoviePage.EditButton.Click();

            editMoviePage.AssertRecordEdited();

            

            

        }

        [Test, Order(5)]    
        public void MarckLastMovieAsWatched()
        {
            allMovisePages.OpenPage();
            allMovisePages.NavigateToLastPage();
            allMovisePages.LastMovieMarkAsWatchetButton.Click();

            watchedMoviePage.OpenPage();
            watchedMoviePage.NavigateToLastPage();

            Assert.That(watchedMoviePage.LastMovieTitle.Text.Trim, Is.EqualTo(lastMovieTitle), "The move was not marked as watchedMoviePage.");


        }

        [Test, Order(6)]
        public void DeleteMove()
        {
            allMovisePages.OpenPage();
            allMovisePages.NavigateToLastPage();
            allMovisePages.LastMovieDeleteButton.Click();
        }
    }
}
