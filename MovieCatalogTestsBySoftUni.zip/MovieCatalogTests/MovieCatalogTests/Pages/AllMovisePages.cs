﻿

using OpenQA.Selenium.Interactions;

namespace MovieCatalogTests.Pages
{
    public class AllMovisePages : BasePage
    {
        public AllMovisePages(IWebDriver driver) : base(driver) 
        {
        
        }

        public virtual string Url => BaseUrl + "/Catalog/All#all";

        public virtual void OpenPage()
        {
            driver.Navigate().GoToUrl(Url);
        }

        //public IWebElement AllMovise => DriverCommand.FindElements(By.XPath("//div[@class='container-fluid p-0']"));

        public IReadOnlyCollection<IWebElement> PageIndexes => driver.FindElements(By.XPath("//a[@class='page-link']"));

        public IReadOnlyCollection<IWebElement> AllMovies => driver.FindElements(By.XPath("//div[@class=\"col-lg-4\"]"));

        public IWebElement LastMovieTitle => AllMovies.Last().FindElement(By.XPath(".//h2"));

        public IWebElement LastMovieEditButton => AllMovies.Last().FindElement(By.XPath("//a[@class=\"btn btn-outline-success\"]"));

        public IWebElement LastMovieDeleteButton => AllMovies.Last().FindElement(By.XPath("//a[@class=\"btn btn-danger\"]"));

        public IWebElement LastMovieMarkAsWatchetButton => AllMovies.Last().FindElement(By.XPath("//a[@class=\"btn btn-info\"]"));

        public void NavigateToLastPage()
        {
            Actions action = new Actions(driver);
            action.ScrollToElement(PageIndexes.Last()).Perform();
            PageIndexes.Last().Click();
        }
    }
}
