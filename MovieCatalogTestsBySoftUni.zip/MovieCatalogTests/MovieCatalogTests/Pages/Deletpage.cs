﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieCatalogTests.Pages
{
    internal class Deletpage: BasePage
    {
        public DeletePage(IWebDriver driver) : base(driver) 
        {
        
        }
        
    }
}
