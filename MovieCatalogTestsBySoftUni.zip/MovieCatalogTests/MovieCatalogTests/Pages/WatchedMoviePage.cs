﻿

namespace MovieCatalogTests.Pages
{
    public class WatchedMoviePage : AllMovisePages


    { 
        public WatchedMoviePage(IWebDriver driver) : base(driver) 
        {
        
        }

        public override string Url => BaseUrl + "/Catalog/Watched#watched";

        public override void OpenPage()
        {
            driver.Navigate().GoToUrl(Url);
        }
    }
}
